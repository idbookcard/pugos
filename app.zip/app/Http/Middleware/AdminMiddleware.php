<?php
namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class AdminMiddleware
{
    public function handle(Request $request, Closure $next)
    {
        if (!Auth::check()) {
            return redirect()->route('adminss.login'); // ✅ 未登录跳转到管理员登录
        }

        if (!Auth::user()->is_admin) { // ✅ 确保 `users` 表有 `is_admin` 字段
            abort(403, '您没有权限访问此页面');
        }

        return $next($request);
    }
}

