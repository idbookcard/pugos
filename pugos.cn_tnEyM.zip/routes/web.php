<?php

use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
Route::get('/', 'HomeController@index')->name('home');
Route::get('/packages', 'PackageController@index')->name('packages');
Route::get('/packages/monthly', 'PackageController@monthly')->name('packages.monthly');
Route::get('/packages/single', 'PackageController@single')->name('packages.single');
Route::get('/packages/third-party', 'PackageController@thirdParty')->name('packages.third-party');
Route::get('/packages/guest-post', 'PackageController@guestPost')->name('packages.guest-post');
Route::get('/packages/{package}', 'PackageController@show')->name('packages.show');

// Authentication Routes
Auth::routes();

// Customer Routes (protected by auth middleware)
Route::middleware(['auth'])->prefix('customer')->group(function () {
    Route::get('/dashboard', 'Customer\DashboardController@index')->name('customer.dashboard');
    Route::get('/orders', 'Customer\OrderController@index')->name('customer.orders');
    Route::get('/orders/{order}', 'Customer\OrderController@show')->name('customer.orders.show');
    Route::get('/packages/{package}/order', 'Customer\OrderController@create')->name('customer.orders.create');
    Route::post('/packages/{package}/order', 'Customer\OrderController@store')->name('customer.orders.store');
    
    // Wallet/Balance Management
    Route::get('/wallet', 'Customer\WalletController@index')->name('customer.wallet');
    Route::post('/wallet/deposit', 'Customer\WalletController@deposit')->name('customer.wallet.deposit');
});

// Admin Routes (protected by admin middleware)
Route::middleware(['auth', 'admin'])->prefix('admin')->group(function () {
    Route::get('/dashboard', 'Admin\DashboardController@index')->name('admin.dashboard');
    
    // Package Management
    Route::resource('packages', 'Admin\PackageController');
    
    // Order Management
    Route::get('/orders', 'Admin\OrderController@index')->name('admin.orders');
    Route::get('/orders/{order}', 'Admin\OrderController@show')->name('admin.orders.show');
    Route::patch('/orders/{order}/status', 'Admin\OrderController@updateStatus')->name('admin.orders.update.status');
    Route::post('/orders/{order}/send-to-third-party', 'Admin\OrderController@sendToThirdParty')->name('admin.orders.send-to-third-party');
    
    // Backlink Report Management
    Route::post('/orders/{order}/reports', 'Admin\ReportController@store')->name('admin.reports.store');
    Route::delete('/reports/{report}', 'Admin\ReportController@destroy')->name('admin.reports.destroy');
    
    // User Management
    Route::resource('users', 'Admin\UserController');
    
    // Third Party API Management
    Route::get('/third-party', 'Admin\ThirdPartyController@index')->name('admin.third-party');
    Route::post('/third-party/sync', 'Admin\ThirdPartyController@sync')->name('admin.third-party.sync');
    Route::get('/third-party/settings', 'Admin\ThirdPartyController@settings')->name('admin.third-party.settings');
    Route::post('/third-party/settings', 'Admin\ThirdPartyController@updateSettings')->name('admin.third-party.settings.update');
    
    // Guest Post Management
    Route::get('/guest-posts', 'Admin\GuestPostController@index')->name('admin.guest-posts');
    Route::get('/guest-posts/create', 'Admin\GuestPostController@create')->name('admin.guest-posts.create');
    Route::post('/guest-posts', 'Admin\GuestPostController@store')->name('admin.guest-posts.store');
    Route::get('/guest-posts/{package}/edit', 'Admin\GuestPostController@edit')->name('admin.guest-posts.edit');
    Route::put('/guest-posts/{package}', 'Admin\GuestPostController@update')->name('admin.guest-posts.update');
    Route::delete('/guest-posts/{package}', 'Admin\GuestPostController@destroy')->name('admin.guest-posts.destroy');
});

// API Routes for Third Party Integration
Route::prefix('api')->group(function () {
    Route::post('/webhooks/third-party/order-update', 'Api\ThirdPartyWebhookController@orderUpdate');
});
