{{-- resources/views/packages/index.blade.php --}}
@extends('layouts.app')

@section('title', '外链服务列表 - SEO外链服务平台')

@section('content')
<div class="container py-4">
    <div class="page-header">
        <div class="row align-items-center">
            <div class="col-md-7">
                <h1 class="fw-bold">外链服务列表</h1>
                <p class="text-muted">选择适合您网站的优质外链服务</p>
            </div>
            <div class="col-md-5">
                <form action="{{ route('packages') }}" method="GET" class="d-flex">
                    <input type="text" name="search" class="form-control" placeholder="搜索服务名称..." value="{{ request('search') }}">
                    <button type="submit" class="btn btn-primary ms-2">搜索</button>
                </form>
            </div>
        </div>
    </div>
    
    <!-- 过滤器 -->
    <div class="card border-0 shadow-sm mb-4">
        <div class="card-body">
            <div class="row align-items-center">
                <div class="col-lg-3 mb-2 mb-lg-0">
                    <label class="form-label fw-bold">服务类型</label>
                    <ul class="nav nav-pills package-filter">
                        <li class="nav-item">
                            <a class="nav-link {{ request()->routeIs('packages') && !request()->routeIs('packages.*') ? 'active' : '' }}" href="{{ route('packages') }}">全部</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link {{ request()->routeIs('packages.monthly') ? 'active' : '' }}" href="{{ route('packages.monthly') }}">月度</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link {{ request()->routeIs('packages.single') ? 'active' : '' }}" href="{{ route('packages.single') }}">单项</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link {{ request()->routeIs('packages.third-party') ? 'active' : '' }}" href="{{ route('packages.third-party') }}">特色</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link {{ request()->routeIs('packages.guest-post') ? 'active' : '' }}" href="{{ route('packages.guest-post') }}">软文</a>
                        </li>
                    </ul>
                </div>
                
                <div class="col-lg-3 mb-2 mb-lg-0">
                    <label for="sort" class="form-label fw-bold">排序方式</label>
                    <select id="sort" class="form-select" onchange="location = this.value;">
                        <option value="{{ request()->fullUrlWithQuery(['sort' => 'recommended']) }}" {{ request('sort') == 'recommended' ? 'selected' : '' }}>推荐顺序</option>
                        <option value="{{ request()->fullUrlWithQuery(['sort' => 'price_asc']) }}" {{ request('sort') == 'price_asc' ? 'selected' : '' }}>价格：从低到高</option>
                        <option value="{{ request()->fullUrlWithQuery(['sort' => 'price_desc']) }}" {{ request('sort') == 'price_desc' ? 'selected' : '' }}>价格：从高到低</option>
                        <option value="{{ request()->fullUrlWithQuery(['sort' => 'delivery_asc']) }}" {{ request('sort') == 'delivery_asc' ? 'selected' : '' }}>交付时间：最快</option>
                        <option value="{{ request()->fullUrlWithQuery(['sort' => 'da_desc']) }}" {{ request('sort') == 'da_desc' ? 'selected' : '' }}>DA值：最高</option>
                    </select>
                </div>
                
                <div class="col-lg-3 mb-2 mb-lg-0">
                    <label for="price_range" class="form-label fw-bold">价格范围</label>
                    <select id="price_range" class="form-select" onchange="location = this.value;">
                        <option value="{{ request()->fullUrlWithQuery(['price' => '']) }}" {{ request('price') == '' ? 'selected' : '' }}>所有价格</option>
                        <option value="{{ request()->fullUrlWithQuery(['price' => '0-199']) }}" {{ request('price') == '0-199' ? 'selected' : '' }}>¥0 - ¥199</option>
                        <option value="{{ request()->fullUrlWithQuery(['price' => '200-499']) }}" {{ request('price') == '200-499' ? 'selected' : '' }}>¥200 - ¥499</option>
                        <option value="{{ request()->fullUrlWithQuery(['price' => '500-999']) }}" {{ request('price') == '500-999' ? 'selected' : '' }}>¥500 - ¥999</option>
                        <option value="{{ request()->fullUrlWithQuery(['price' => '1000-1999']) }}" {{ request('price') == '1000-1999' ? 'selected' : '' }}>¥1000 - ¥1999</option>
                        <option value="{{ request()->fullUrlWithQuery(['price' => '2000+']) }}" {{ request('price') == '2000+' ? 'selected' : '' }}>¥2000以上</option>
                    </select>
                </div>
                
                <div class="col-lg-3 text-lg-end mt-3 mt-lg-0">
                    <div class="d-flex justify-content-between">
                        <span class="fw-bold">显示：</span>
                        <div class="btn-group ms-2" role="group">
                            <button type="button" class="btn btn-outline-secondary btn-sm {{ request('view') == 'grid' || !request('view') ? 'active' : '' }}" onclick="location = '{{ request()->fullUrlWithQuery(['view' => 'grid']) }}'">
                                <i class="bi bi-grid-3x3-gap-fill"></i>
                            </button>
                            <button type="button" class="btn btn-outline-secondary btn-sm {{ request('view') == 'list' ? 'active' : '' }}" onclick="location = '{{ request()->fullUrlWithQuery(['view' => 'list']) }}'">
                                <i class="bi bi-list-ul"></i>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- 当前过滤器标签 -->
    @if(request('search') || request('price') || request('sort') != 'recommended')
    <div class="mb-4">
        <div class="d-flex flex-wrap align-items-center">
            <span class="fw-bold me-2">当前筛选：</span>
            @if(request('search'))
            <div class="filter-tag">
                搜索：{{ request('search') }}
                <a href="{{ request()->fullUrlWithQuery(['search' => '']) }}" class="ms-1"><i class="bi bi-x"></i></a>
            </div>
            @endif
            
            @if(request('price'))
            <div class="filter-tag">
                价格：{{ request('price') }}
                <a href="{{ request()->fullUrlWithQuery(['price' => '']) }}" class="ms-1"><i class="bi bi-x"></i></a>
            </div>
            @endif
            
            @if(request('sort') && request('sort') != 'recommended')
            <div class="filter-tag">
                排序：{{ __('packages.sort.' . request('sort')) }}
                <a href="{{ request()->fullUrlWithQuery(['sort' => '']) }}" class="ms-1"><i class="bi bi-x"></i></a>
            </div>
            @endif
            
            <a href="{{ route('packages') }}" class="btn btn-sm btn-outline-secondary ms-auto">清除所有筛选</a>
        </div>
    </div>
    @endif
    
    @if(request('view') == 'list')
    <!-- 列表视图 -->
    <div class="card border-0 shadow-sm mb-4">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table package-table mb-0">
                    <thead>
                        <tr>
                            <th>服务名称</th>
                            <th>类型</th>
                            <th>交付时间</th>
                            <th>价格</th>
                            <th>操作</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($packages as $package)
                        <tr>
                            <td>
                                <div class="d-flex align-items-center">
                                    @if($package->is_featured)
                                    <span class="badge bg-warning me-2">推荐</span>
                                    @endif
                                    <div>
                                        <h6 class="mb-1">{{ $package->name }}</h6>
                                        <p class="text-muted small mb-0">{{ Str::limit(strip_tags($package->description), 80) }}</p>
                                    </div>
                                </div>
                            </td>
                            <td>
                                @if($package->package_type == 'monthly')
                                    <span class="badge bg-primary">月度套餐</span>
                                @elseif($package->package_type == 'single')
                                    <span class="badge bg-info">单项套餐</span>
                                @elseif($package->package_type == 'third_party')
                                    <span class="badge bg-secondary">特色外链</span>
                                @else
                                    <span class="badge bg-success">软文外链</span>
                                @endif
                            </td>
                            <td>{{ $package->delivery_days }}天</td>
                            <td class="fw-bold">¥{{ number_format($package->price, 2) }}</td>
                            <td>
                                <a href="{{ route('packages.show', $package) }}" class="btn btn-sm btn-primary">查看详情</a>
                            </td>
                        </tr>
                        @empty
                        <tr>
                            <td colspan="5" class="text-center py-5">
                                <div class="d-flex flex-column align-items-center">
                                    <i class="bi bi-search fs-1 text-muted mb-3"></i>
                                    <p class="text-muted mb-3">未找到符合条件的服务</p>
                                    <a href="{{ route('packages') }}" class="btn btn-sm btn-primary">查看所有服务</a>
                                </div>
                            </td>
                        </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    @else
    <!-- 网格视图 -->
    <div class="row">
        @forelse($packages as $package)
        <div class="col-lg-4 col-md-6 mb-4">
            <div class="card h-100 package-card {{ $package->is_featured ? 'featured-package' : '' }}">
                @if($package->is_featured)
                <span class="featured-badge">推荐</span>
                @endif
                
                <div class="card-header {{ $package->is_featured ? '' : 'bg-primary text-white' }}">
                    <h5 class="card-title mb-0">{{ Str::limit($package->name, 40) }}</h5>
                </div>
                
                <div class="card-body">
                    <div class="text-center mb-3">
                        <span class="price">¥{{ number_format($package->price, 2) }}</span>
                        <p class="text-muted">{{ $package->delivery_days }}天交付</p>
                    </div>
                    
                    <div class="mb-3">
                        <p>{{ Str::limit(strip_tags($package->description), 120) }}</p>
                    </div>
                    
                    <ul class="feature-list list-unstyled">
                        @if($package->package_type == 'monthly')
                            <li>包含多周期外链建设</li>
                            <li>多样化外链来源</li>
                        @elseif($package->package_type == 'single')
                            <li>单次外链建设</li>
                            <li>快速交付</li>
                        @elseif($package->package_type == 'third_party')
                            <li>特色优质外链</li>
                            <li>第三方合作资源</li>
                        @elseif($package->package_type == 'guest-post')
                            <li>高质量软文外链</li>
                            <li>DA{{ $package->guest_post_da }}站点</li>
                        @endif
                        <li>详细外链报告</li>
                    </ul>
                </div>
                
                <div class="card-footer bg-transparent border-0 text-center">
                    <a href="{{ route('packages.show', $package) }}" class="btn btn-primary">查看详情</a>
                </div>
            </div>
        </div>
        @empty
        <div class="col-12">
            <div class="card border-0 shadow-sm">
                <div class="card-body text-center py-5">
                    <i class="bi bi-search fs-1 text-muted mb-3"></i>
                    <h4>未找到符合条件的服务</h4>
                    <p class="text-muted mb-3">尝试使用不同的筛选条件，或查看我们的所有服务</p>
                    <a href="{{ route('packages') }}" class="btn btn-primary">查看所有服务</a>
                </div>
            </div>
        </div>
        @endforelse
    </div>
    @endif
    
    <!-- 分页 -->
    <div class="d-flex justify-content-center mt-4">
        {{ $packages->appends(request()->query())->links() }}
    </div>
    
    <!-- SEO服务信息 -->
    <div class="card border-0 shadow-sm mt-4">
        <div class="card-body">
            <h4 class="mb-3">关于我们的外链服务</h4>
            <p>我们的SEO外链服务平台提供多种类型的优质外链建设解决方案，帮助提升您网站在Google搜索中的排名。无论您是需要全面的月度外链套餐，还是针对特定需求的单项服务，我们都能为您提供专业、高效的SEO支持。</p>
            
            <div class="row mt-4">
                <div class="col-md-6">
                    <h5 class="fw-bold"><i class="bi bi-check-circle-fill text-success me-2"></i>月度套餐</h5>
                    <p>我们的月度套餐提供全方位的外链建设策略，按周规划不同类型的外链建设工作，覆盖多样化的外链渠道，持续提升您网站的权重和排名。</p>
                </div>
                <div class="col-md-6">
                    <h5 class="fw-bold"><i class="bi bi-check-circle-fill text-success me-2"></i>单项服务</h5>
                    <p>针对特定需求的单项外链服务，包括高DA外链、EDU外链、社交书签、目录提交等多种类型，满足您对特定外链资源的需求。</p>
                </div>
                <div class="col-md-6">
                    <h5 class="fw-bold"><i class="bi bi-check-circle-fill text-success me-2"></i>特色外链</h5>
                    <p>与第三方平台合作的优质外链资源，提供更丰富的外链选择，包括各类专业网站、论坛和博客平台的高质量外链。</p>
                </div>
                <div class="col-md-6">
                    <h5 class="fw-bold"><i class="bi bi-check-circle-fill text-success me-2"></i>软文外链</h5>
                    <p>在高权重网站上发布原创内容并包含您的链接，提供持久的SEO价值和品牌曝光，是最有效的外链建设方式之一。</p>
                </div>
            </div>
        </div>
    </div>
</div>

@push('styles')
<style>
.package-filter .nav-link {
    padding: 0.25rem 1rem;
    font-size: 0.9rem;
}

.filter-tag {
    display: inline-block;
    background-color: #f8f9fa;
    border: 1px solid #dee2e6;
    border-radius: 2rem;
    padding: 0.25rem 0.75rem;
    margin-right: 0.5rem;
    margin-bottom: 0.5rem;
    font-size: 0.875rem;
}

.filter-tag a {
    color: #6c757d;
}

.filter-tag a:hover {
    color: #dc3545;
}

.package-table th, .package-table td {
    padding: 1rem;
}

.featured-package {
    border: 2px solid var(--accent-color);
}

.featured-badge {
    position: absolute;
    top: -10px;
    right: -10px;
    background-color: var(--accent-color);
    color: #333;
    padding: 0.25rem 0.75rem;
    border-radius: 1rem;
    font-size: 0.75rem;
    font-weight: 600;
    box-shadow: 0 2px 5px rgba(0,0,0,0.2);
}
</style>
@endpush
@endsection